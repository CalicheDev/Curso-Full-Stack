//factorial-for.js -> Este archivo debe calcular el factorial de 10 utilizando un solo bucle for

// let x = 0;
// let f = 0;
var factorial= 10;
var n = 5;

for (let i = 1; i <= n; i++) {
    factorial = factorial * i;
    console.log(factorial)
}

