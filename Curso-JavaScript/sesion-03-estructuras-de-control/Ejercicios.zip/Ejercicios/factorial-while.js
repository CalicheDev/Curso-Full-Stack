//factorial-while.js -> Este archivo debe calcular el factorial de 10 utilizando un bucle while

var factorial= 10;

var i = 1;
var max = 5;

while (i < max){
    factorial = factorial * i;
    console.log(factorial)
    i++;
}